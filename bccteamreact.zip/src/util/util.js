export const API_URL = "https://api.bccunitedteam.uz/";
